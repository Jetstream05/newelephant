<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width">
  <title>The New Elephant</title>
  <link href="style.css" rel="stylesheet" type="text/css" />
   <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
  <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Roboto+Condensed:wght@700&display=swap" rel="stylesheet">
</head>

<body>


<!-- Nav Bar -->
<section id = "title">
     <nav class="navbar navbar-expand-lg navbar-dark">
    <div class="container-fluid">
    <img src="Logo.png" alt="" height="50" width="50">
    <a class="navbar-brand" href="index.html">The New Elephant</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="index.html">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="mission.html">Mission</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="products.html">Products</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="contact.html">Contact Us</a>
        </li>
         
<!--         <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Dropdown
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
            <li><a class="dropdown-item" href="#">Action</a></li>
            <li><a class="dropdown-item" href="#">Another action</a></li>
            <li><hr class="dropdown-divider"></li>
            <li><a class="dropdown-item" href="#">Something else here</a></li>
          </ul>
        </li> -->
<!--         <li class="nav-item">
          <a class="nav-link disabled">Disabled</a>
        </li>
      </ul>
      <form class="d-flex">
        <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
        <button class="btn btn-outline-success" type="submit">Search</button>
      </form> -->
    </div>
  </div>
</nav>



<div class="container">
     <div class="row gy-5">
        <div class="col-12 col-md-8">
          <div>
            <h1 id = "header">Bringing Love and Joy Everywhere.</h1>
          </div>
          <button type="button" class = "btn btn-dark btn-outline-white btn-lg"><i class="fa-solid fa-bag-shopping"></i><a href="products.html" class = "homeLinks"> Shop Here!</a></button>
          
       </div>
        <div class="col-6 col-md-4" >
    
       <img class="header-image" src="Homepage Picture.jpg" id = "elephantPictureOne">

      </div>
    </div>
  </section>

<div class = "container">
  <section id="features">

    
   <!-- Features -->
  </section>
  </div>
  <div class = "container-fluid">
  <div class="container">
  <div class="row">
    
    <div class="col-sm" id = "center">
      <i class="fa-solid fa-thumbs-up symbol"></i>
      <h3><strong>Quality Products</strong></h3>
      <p id = "grayTextColor">Products found and nurtured with care.</p>
    </div>
    
    <div class="col-sm" id = "center">
      <i class="fa-solid fa-user-shield symbol"></i>
      <h3><strong>Caring Staff</strong></h3>
      <p id = "grayTextColor">We will provide you answers to any questions you have, guranteed!</p>
    </div>
    
    <div class="col-sm" id = "center">
      <i class="fa-solid fa-hand-holding-heart symbol"></i>
      <h3><strong>Charity</strong></h3>
      <p id = "grayTextColor">Portions of our profit go to charities around the Chicago-land area.</p>
    </div>
    
  </div>
</div>
</div>

<!-- Testimonials -->

  <section id="testimonials">
    <div id="carouselExampleIndicators" class="carousel slide background-testimonials" data-bs-ride="carousel"> 
  <div class="carousel-indicators">
    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="1" aria-label="Slide 2"></button>
   
  </div>
  <div class="carousel-inner">
    <div class="carousel-item active">
      <h2 id = "newsText">The New Elephant Moves!</h2>
      <p id = "whiteTextColor">After being in the same location for so long, The New Elephant is finally moving!</p>
      <img src="News1.jpg" alt="" id="sliderImage">
      
    </div>
    <div class="carousel-item">
      <h2  id = "newsText">Antique Furiture!</h2>
       <p id = "whiteTextColor">Buy this furniture now on our Chairish page!</p>
      <img src="News2.jpg" alt="" id="sliderImage">
    </div>
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>
  </section>
<!-- Call To Action -->
    
  <section id="cta">

    <h3 id = "headerTwo">Take Your Step In Helping Chicago.</h3>
    <button type="button" class = "btn btn-dark btn-outline-white btn-lg"><i class="fa-solid fa-bag-shopping"></i><a href="products.html" class = "homeLinks"> Shop Here!</a></button>
    <br>
    <br>
    <div class="d-inline-block mx-2"><i class="fab fa-facebook-f"></i>
      </div>
    <div class="d-inline-block mx-2"><i class="fab fa-instagram"></i>
      </div>
    <a href = "mailto:hello@newelephant.org">
    <div class="d-inline-block mx-2"><i class="fas fa-envelope"></i>
      </div>  
    </a>
    <p id = "text-align">© Copyright TheNewElephant</p>

  </section>

  
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
  <script src="script.js"></script>
  <script src="https://kit.fontawesome.com/bf20a4d927.js" crossorigin="anonymous"></script>
</body>

</html>